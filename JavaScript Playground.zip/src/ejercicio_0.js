function crearTablero() {
  const tabla = {
  Harry: 300,
  Luna: 280,
  Cedric: 270
  };
  return tabla;
}

console.log(crearTablero());